
const execute = (cliente, msg, args) =>{
  return msg.reply("Utilize formato !submit name ap ap ap");
}
module.exports ={
  name: "help",
  help:"Utilize formato !submit name ap ap dp",
  execute
};